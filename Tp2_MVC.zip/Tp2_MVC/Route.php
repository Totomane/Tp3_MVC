<?php

declare(strict_types=1);

require 'controller/ArticleControllers.php';
require 'controller/CommentController.php';

// Définition des routes sous forme de tableau associatif
// Chaque route est liée à une méthode spécifique d'un contrôleur
$routes = [
    'home' => 'list',
    'view_article' => 'viewArticle',
    'add_comment' => 'addComment',
    'add_article' => 'list',
    'delete_comment' => 'deleteComment',
];

// Récupération de l'action demandée via l'URL (paramètre GET 'action')
// Si aucune action n'est spécifiée, on affiche la page d'accueil par défaut
$action = $_GET['action'] ?? 'home';
$id = isset($_GET['id']) ? (int)$_GET['id'] : null; // Récupération optionnelle d'un identifiant

// Instanciation des contrôleurs
$articleController = new ArticleController();
$commentController = new CommentController();

// Vérification si l'action existe bien dans la liste des routes définies
if (array_key_exists($action, $routes)) {
    $method = $routes[$action]; // Récupération de la méthode associée

    // Vérification et appel de la méthode appropriée
    if (method_exists($articleController, $method)) {
        $articleController->$method($id);
        return;
    } elseif (method_exists($commentController, $method)) {
        $commentController->$method($id);
        return;
    }
}

// Gestion des erreurs : si la route n'existe pas, on affiche une erreur 404
http_response_code(404);
echo "Erreur 404 : Action non trouvée";
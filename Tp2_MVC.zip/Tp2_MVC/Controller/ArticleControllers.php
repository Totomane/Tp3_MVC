<?php
declare(strict_types=1);
require 'model/ArticleModel.php';

class ArticleController {
    private ArticleModel $model;

    public function __construct() {
        $this->model = new ArticleModel();
    }

    public function list(): void {
        $articles = $this->model->getLatestArticles(5);
        require 'views/articles/list.php';
    }


    public function show(int $id): void {
        $article = $this->model->getArticle($id);
        $comments = $this->model->getCommentsByArticle($id);

        if ($article) {
            require 'views/articles/list.php';
        } else {
            $this->error(404, "Article non trouvé");
        }
    }


    public function add(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titre = trim($_POST['titre'] ?? '');
            $corps = trim($_POST['corps'] ?? '');

            if (empty($titre) || empty($corps)) {
                echo "<script>alert('Tous les champs doivent être remplis.');</script>";
                require 'views/articles/addart.php';
                return;
            }

            $success = $this->model->addArticle($titre, $corps);
            if ($success) {
                echo "<script>alert('Article ajouté avec succès.');</script>";
                header("Location: index.php?action=list");
                exit;
            } else {
                echo "<script>alert('Erreur lors de l\'ajout de l\'article.');</script>";
                require 'views/articles/addart.php';
            }
        } else {
            require 'views/articles/addart.php';
        }
    }



    public function error(int $code, string $msg): void {
        http_response_code($code);
        require "views/{$code}.php";
        die();
    }
}
?>


    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="public/btrobin.css" />
        <title>Ajouter un Article</title>
        <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
        <META HTTP-EQUIV="Expires" CONTENT="-1">
    </head>
    <body>
    <header>
        <h1>Ajouter un Nouvel Article</h1>
    </header>
    <div class="container">

        <form method="post" action="index.php?action=add_article" class="article">
            <label for="login">Identifiant :</label><br>
            <input type="text" name="login" required><br><br>

            Mot de passe : <br>
            <input type="password" name="mdp" required><br><br>
            Titre de larticle : <br>
            <input type="text" name="titre" required><br><br>
            Contenu de larticle : <br>
            <textarea name="corps" rows="5" cols="40" required></textarea><br><br>

            <input type="submit" value="Ajouter l'article"><br>
        </form>
<?php
declare(strict_types=1);

class ArticleModel {
    private PDO $db;

    public function __construct() {
        $dsn = 'mysql:host=localhost;dbname=blog;charset=utf8';
        $username = 'root';
        $password = '';
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];
        $this->db = new PDO($dsn, $username, $password, $options);
    }

    public function getLatestArticles(int $limit = 5): array {
        $query = "SELECT * FROM articles ORDER BY date_create DESC LIMIT :limit";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getArticle(int $id): ?array {
        $query = "SELECT * FROM articles WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch() ?: null;
    }

    public function getCommentsByArticle(int $articleId): array {
        $query = "SELECT * FROM comments WHERE article_id = :article_id ORDER BY date_creat ASC";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':article_id', $articleId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function addArticle(string $title, string $body): bool {
        $query = "INSERT INTO articles (title, body, date_creat) VALUES (:title, :body, NOW())";
        $stmt = $this->db->prepare($query);
        return $stmt->execute([
            ':title' => $title,
            ':body' => $body
        ]);
    }
}

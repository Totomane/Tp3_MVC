
<?php

const DB_HOST = "localhost";
const DB_PORT = "3306";
const DB_NAME = "ecommerce";
const DB_USER = "root";
const DB_PWD = "";

?>

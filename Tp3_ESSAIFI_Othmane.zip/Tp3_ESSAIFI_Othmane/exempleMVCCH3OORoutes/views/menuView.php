<!DOCTYPE html>
<html lang="fr">
    <head>
        <title>Acceuil</title>
        <meta charset="utf-8">
    </head>
    <link rel="stylesheet" href="public/bitnami2.css" />
    <body>
    <h1>PAge d'acceuil</h1>
    <ul>
    <li>
    <a href="index.php?action=products">Liste des Produits</a>
    </li>
    <li>
    <a href="index.php?action=ajout">Ajouter un produit</a>
    </li>
     <li>
    <a href="index.php?action=recherche">Rechercher un produit</a>
    </li>
  </ul>
    </body>
</html>